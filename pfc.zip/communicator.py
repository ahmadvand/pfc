import os

import serial

import paho.mqtt.client as mqtt



from pyfirmata import Arduino, util
import pyfirmata

import time, threading

'''
def foo(arduino=None):
    print("Sending: " + time.ctime())
    arduino.send_sysex(pyfirmata.pyfirmata.STRING_DATA, util.str_to_two_byte_iter(time.ctime()))
    threading.Timer(10, foo).start()


def message_handler(*args, **kwargs):
    print(util.two_byte_iter_to_str(args))

arduino = Arduino("/dev/ttyACM0")
# start an iterator thread so that serial buffer doesn't overflow
it = util.Iterator(arduino)
it.start()
arduino.add_cmd_handler(pyfirmata.pyfirmata.STRING_DATA, message_handler)

arduino.send_sysex(pyfirmata.pyfirmata.STRING_DATA, util.str_to_two_byte_iter("PING"))

foo()
'''


class Communicator:
    """Initialising variables"""
    ARDUINO_PORT = None
    rawdata = []
    count = 0
    arduino = None
    client = None

    def __init__(self):
        self.ARDUINO_PORT = self.get_arduino_port()

    def get_arduino_port(self):
        return "/dev/" + os.popen("dmesg | egrep ttyACM | cut -f3 -d: | tail -n1").read().strip()

    def connect_arduino(self):
        """Opening of the serial port"""
        try:
            # self.arduino = serial.Serial(self.port, timeout=1)
            print('Looking for Arduino port...')
            self.arduino = Arduino(self.ARDUINO_PORT)
            print(self.arduino)
            print('Connecting to Arduino...')
            # start an iterator thread so that serial buffer doesn't overflow
            it = util.Iterator(self.arduino)
            it.start()
            self.arduino.add_cmd_handler(pyfirmata.pyfirmata.STRING_DATA, self.arduino_message_handler)
            self.arduino.send_sysex(pyfirmata.pyfirmata.STRING_DATA, util.str_to_two_byte_iter("PING"))
        except:
            print('Please check the port')

    def arduino_message_handler(self, *args, **kwargs):
        data = util.two_byte_iter_to_str(args)
        print(data)
        self.client.publish("ID", data)

    def send_to_arduino(self, data):
        self.arduino.send_sysex(pyfirmata.pyfirmata.STRING_DATA, util.str_to_two_byte_iter(data))

    def on_connect(self, client, userdata, flags, rc):
        print("connected with result code " + str(rc))
        client.subscribe("Arduino")

    def on_message(self, client, userdata, msg):
        print("A")
        print(str(msg.payload))
        print("B")
        # data = json.loads(msg.payload)
        # print("C")
        # print(data)
        # array = np.array(data)
        print("D")
        # print(array)
        d = str(msg.payload)
        print(d)
        d = d.replace("b", "").replace("'", "").replace('"', "") # + "\n"
        print(d)
        print("C")
        self.send_to_arduino(d)#.encode())
        print("Y")

    def connect_mqtt(self):
        self.client = mqtt.Client()
        self.client.on_connect = self.on_connect
        self.client.on_message = self.on_message
        self.client.connect('127.0.0.1', 1883, 60)
        self.client.loop_forever()

    def clean(self, l):  # L is a list
        newl = []  # initialising the new list
        for i in range(len(l)):
            temp = l[i][2:]
            newl.append(temp[:-5])
        return newl

    def write(self, l):
        file = open("data.txt", mode='w')
        for i in range(len(l)):
            file.write(l[i] + '\n')
        file.close()


comm = Communicator()
comm.connect_arduino()
comm.connect_mqtt()

'''

class Comm(Module):
    """
    Handles the communication between python and arduino
    AttachTo: ""
    """

    NAME = "Communicator"

    def __init__(self, port):
        super(Comm,self).__init__(Comm.NAME)
        self.board = Arduino(port)
        # start an iterator thread so that serial buffer doesn't overflow
        it = util.Iterator(self.board)
        it.start()

        self.board.add_cmd_handler(pyfirmata.pyfirmata.STRING_DATA, self._messageHandler)

    def _messageHandler(self, *args, **kwargs):
        print(util.two_byte_iter_to_str(args))

    def update(self):
        super(Comm,self).update()

    def writeData(self,data):
        #print data
        self.board.send_sysex(pyfirmata.pyfirmata.STRING_DATA,data)

    def dispose(self):
        super(Comm,self).dispose()
        try:
            self.board.exit()
        except AttributeError:
            print("exit() raised an AttributeError unexpectedly!"+self.toString())

'''

"""Receiving data and storing it in a list"""
'''
while True:
    # bytesToRead = arduino.inWaiting()
    # ser.read(bytesToRead)
    # rawdata.append(str(arduino.readline()))
    # count+=1
    data = arduino.readline()
    if data:
        data = str(data).replace(r"\r\n", "").replace("b", "").replace("'", "")
        print(data)
        client.publish("ID", data);
print(rawdata)

cleandata = clean(rawdata)
write(cleandata)
'''


'''
import warnings
import serial.tools.list_ports

for p in serial.tools.list_ports.comports():
    print(p.device)
    print(p.interface)
    # print(p.product)

arduino_ports = [
    p.device
    for p in serial.tools.list_ports.comports()
    if p.manufacturer & 'Arduino' in p.manufacturer
]
if not arduino_ports:
    raise IOError("No Arduino found")
if len(arduino_ports) > 1:
    warnings.warn('Multiple Arduinos found - using the first')

print(arduino_ports[0])
'''
